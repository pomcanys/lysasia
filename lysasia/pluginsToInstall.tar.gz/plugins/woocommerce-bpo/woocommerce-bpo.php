<?php
/*
Plugin Name: BPONextdoor ecommerce features
Plugin URI: http://bponextdoor.com
Description: Adding some ecommerce features from BPONextdoor
Version: 1.0
Author: BPO Nextdoor
Author URI: http://bponextdoor.com
*/


add_action( 'plugins_loaded', array( 'WC_BPO', 'get_instance' ) );

if ( ! class_exists( 'WC_BPO' ) ) :

class WC_BPO {
	/** @var Class instance */
	protected static $instance = null;

	/**
	 * Constructor
	 */
	public function __construct() {
		add_filter( 'woocommerce_get_sections_products', array( $this, 'bpofeatures_add_section' ) );
		add_filter( 'woocommerce_get_settings_products', array( $this, 'bpofeatures_all_settings' ), 10, 2 );
		add_action( 'woocommerce_before_cart_totals',  array( $this, 'my_depot_cart_field' ) );
		
		add_action( 'woocommerce_checkout_update_order_meta', array( $this, 'set_which_restaurant') );
		add_action( 'woocommerce_checkout_update_order_meta', array( $this, 'depot_pintos_subcharge_order_meta') );
		add_action( 'woocommerce_admin_order_data_after_billing_address', array( $this, 'depot_pintos_subcharge_display_admin_order_meta'), 10, 1 );
		add_action( 'woocommerce_admin_order_data_after_billing_address', array( $this, 'show_which_restaurant'), 10, 1 );

        //add_action( 'woocommerce_order_status_processing', array( $this, 'api_process_order'), 10, 1);
        //add_action( 'woocommerce_order_status_completed', array( $this, 'api_process_order'), 10, 1);
        add_action( 'woocommerce_checkout_update_order_meta', array( $this, 'api_process_order'), 10, 1);

		add_action( 'woocommerce_init',  array( $this, 'depot_pintos_count_save') );
		
		add_action( 'woocommerce_cart_calculate_fees', array( $this, 'depot_pintos_subcharge') );

		wp_register_script('custom_bpo', get_template_directory_uri().'/js/custom.js', array(), false, true);
		wp_enqueue_script('custom_bpo');
	}

	public static function get_instance() {
		if ( null == self::$instance ) {
			self::$instance = new self;
		}
		return self::$instance;
	}	
	
	public function bpofeatures_add_section( $sections ) {
		
		$sections['bpofeatures'] = __( 'BPO Settings', 'text-domain' );
		return $sections;
		
	}
	
	public function bpofeatures_all_settings( $settings, $current_section ) {

		if ( $current_section == 'bpofeatures' ) {
			$settings_bpo = array();
			
			// Add Title to the Settings
			$settings_bpo[] = array( 'name' => __( 'BPO Settings', 'text-domain' ), 'type' => 'title', 'desc' => __( 'The following options are used to configure custom functionality', 'text-domain' ), 'id' => 'bpofeatures' );
			
			// Add first checkbox option
			/* $settings_bpo[] = array(
				'name'     => __( 'Auto-insert into single product page', 'text-domain' ),
				'desc_tip' => __( 'This will automatically insert your slider into the single product page', 'text-domain' ),
				'id'       => 'bpofeatures_auto_insert',
				'type'     => 'checkbox',
				'css'      => 'min-width:300px;',
				'desc'     => __( 'Enable Auto-Insert', 'text-domain' ),
			); */
			
			// Add second text field option
			$settings_bpo[] = array(
				'name'     => __( 'Free Pinto product ID', 'text-domain' ),
				'desc_tip' => __( ' ', 'text-domain' ),
				'id'       => 'bpofeatures_depot_id_free',
				'type'     => 'text',
				'desc'     => __( ' ', 'text-domain' ),
			);
			// Add second text field option
			$settings_bpo[] = array(
				'name'     => __( 'Paid Pinto product ID', 'text-domain' ),
				'desc_tip' => __( ' ', 'text-domain' ),
				'id'       => 'bpofeatures_depot_id_paid',
				'type'     => 'text',
				'desc'     => __( ' ', 'text-domain' ),
			);
			
			$settings_bpo[] = array( 'type' => 'sectionend', 'id' => 'bpofeatures' );
			return $settings_bpo;
		
		} else {
			return $settings;
		}
	}
		
	 /**
	 * Add the DEPOT field to the cart
	 */
	public function my_depot_cart_field() {

		echo '<div id="my_depot_cart_field"><h2>' . __(' ') . '</h2>';

		woocommerce_form_field( 'depot_returned', array(
			'type'          => 'text',
			'class'         => array('my-field-class form-row-wide'),
			'label'         => __('Pintos retouren'),
			'placeholder'   => __(''),
			), abs(1*WC()->session->get( 'pintos_retourned' )) );

		echo '</div>';
		
	}
	public function depot_pintos_count_save() {
		if(isset($_REQUEST['pintos_retourned'])){
			WC()->session->set( 'pintos_retourned', sanitize_text_field($_REQUEST['pintos_retourned']) );
			exit;
		}
	}
	
	public function depot_pintos_subcharge($order_id) {
		if ( is_admin() && ! defined( 'DOING_AJAX' ) )
			return;
		
		$cart_contents_count = WC()->cart->get_cart_contents_count();
		$pintos_retourned = abs(1*WC()->session->get( 'pintos_retourned' ));
		
		$surcharge_count = ($cart_contents_count >= $pintos_retourned) ? ($cart_contents_count - $pintos_retourned) : 0;
		$surcharge_fee = 10;
		
		$surcharge = $surcharge_fee * $surcharge_count;
		
		WC()->cart->add_fee( 'Davon Depot Pintos', $surcharge, true, '' );
	}

    public function depot_pintos_subcharge_order_meta( $order_id ) {
		$cart_contents_count = WC()->cart->get_cart_contents_count();
		$pintos_retourned = abs(1*WC()->session->get( 'pintos_retourned' ));
		
		$surcharge_count = ($cart_contents_count >= $pintos_retourned) ? $pintos_retourned : $cart_contents_count;

		update_post_meta( $order_id, 'pintos_retourned', $surcharge_count );
		WC()->session->set( 'pintos_retourned', 0 );
	}

    public function depot_pintos_subcharge_display_admin_order_meta($order)
    {
        echo '<p><strong>' . __('Pintos Retourned') . ':</strong> ' . get_post_meta($order->id, 'pintos_retourned', true) . '</p>';
    }



    public function set_which_restaurant( $order_id ) {

	    if( strlen($_COOKIE['shop']) ) {
            switch ($_COOKIE['shop']) {
                case 'Maag-Areal':
                    $shop = 1;
                    break;
                case 'Bahnhof Stadelhofen':
                    $shop = 2;
                    break;
            }
        }elseif (strlen($_COOKIE['zipCode'])){
            switch ($_COOKIE['zipCode']) {
                case '8005':
                case '8003':
                case '8004':
                case '8037':
                case '8064':
                    $shop = 1;
                    break;
                case '8001':
                case '8002':
                case '8008':
                case '8006':
                case '8032':
                case '8038':
                case '8044':
                case '8045':
                    $shop = 2;
                    break;
            }
        }

        update_post_meta( $order_id, 'shop', $shop );
    }

    public function show_which_restaurant($order){
        if ( get_post_meta( $order->id, 'shop', true )*1 == 1 ) {
            $shop = 'Maag-Areal';
        }else {
            $shop = 'Bahnhof Stadelhofen';
        }
        echo '<p><strong>'.__('Restaurant').':</strong> ' . $shop . '</p>';
	}

	public function api_process_order ($order_id){
        $order = wc_get_order( $order_id );

        $order_meta = get_post_meta($order_id);

        $orderDayTA = get_post_meta( $order_id, 'wcta_shipping_option_day', true );
        $orderDayD = get_post_meta( $order_id, 'wcso_shipping_option_day', true );
        $orderTimeTA = get_post_meta( $order_id, 'wcta_shipping_option_time', true );
        $orderTimeD = get_post_meta( $order_id, 'wcso_shipping_option_time', true );

        $orderTimeTA = str_replace('.', ':', $orderTimeTA);
        $orderTimeD = str_replace('.', ':', $orderTimeD);
        $orderDayTA = explode('|', $orderDayTa);
        $orderDayD = explode('|', $orderDayD);

        $data = array();

        $data['passwort'] = 'KP4EVER';
        $data['aujrag_datum'] = $orderDayTA[0] ? $orderDayTA[0] : $orderDayD[0];
        $data['aujrag_zeit'] = $orderTimeTA ? $orderTimeTA : $orderTimeD;
        $data['partner_id'] = '';
        $data['empfaenger_name'] = $order_meta[_billing_last_name][0];
        $data['empfaenger_kontakt'] = $order_meta[_billing_first_name][0];
        $data['empfaenger_strasse'] = $order_meta[_billing_address_1][0];
        $data['empfaenger_plz'] = $order_meta[_billing_myfield13][0];
        $data['empfaenger_telefon'] = $order_meta[_billing_phone][0];
        $data['empfaenger_bemerkungen'] = $order_meta[_billing_myfield8][0];

        file_get_contents( "http://www.kurierpro.com/fm/flash/partner/Lys.php?" . http_build_query($data) );

    }


}

endif;
